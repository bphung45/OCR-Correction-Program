loudhum - A simple Racket library for digital humanities exercises
==================================================================

loudhum is a library of Racket routines designed to accompany the
textbook "FunDHum - A Functional Approach to Digital Humanities".
The name is a silly play on Racket (rackets are loud) and "dhum",
one of the many abbreviations of "digital humanities".
